using System;
using Xunit;
using Calculators;
using Moq;
using Calculadora2Test;

namespace TestProjectum
{
    public class UnitTestCalculadoraFibo

    {
        private ICalculator _calculator;
        [Fact]
        public void TestFibo()
        {
            
            _calculator = new Calculator();
            Series seriesentity = new Series(_calculator);
            var calculatorentity = new Calculator();
            Mock<Iseries> Mock = new Mock<Iseries>();
            Mock.Setup(a => a.Fibonacci(5)).Returns(100); 
            
            Console.WriteLine("Serie Fibonacci:", seriesentity.Fibonacci(5));
            
        }
        [Fact]
        public void TestFactori()
        {

            _calculator = new Calculator();
            Series seriesentity = new Series(_calculator);
            var calculatorentity = new Calculator();
            Mock<Iseries> Mock = new Mock<Iseries>();
            Mock.Setup(serie => serie.Factorial(5)).Returns(55);

            Console.WriteLine("Serie Factorial:", seriesentity.Factorial(5));

        }

    }
}
    

    
