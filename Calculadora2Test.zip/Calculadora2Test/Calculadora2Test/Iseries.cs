﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora2Test
{
    public interface Iseries
    {
        public int Factorial(int n);


        public int Fibonacci(int n);
        
    }
}
